package com.LoginMVC.loginmvc.logincontroller;



import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.LoginMVC.loginmvc.entity.User;

@Controller
public class LoginController {
	
	@Autowired
	SessionFactory sf;
	
	@RequestMapping("/gotoshowdata")
	public ModelAndView showData(User u) {
		ModelAndView view=new ModelAndView();
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(User.class);
		List<User> list=cr.list();
		view.addObject("userlist",list);
		s.close();
		view.setViewName("show");
		return view;
	}
	
	@RequestMapping("/login")
	public ModelAndView login(User u) {
		ModelAndView view=new ModelAndView();
		String uname=u.getUsername();
		String pass=u.getPassword();
		
		Session s=sf.openSession();
		Criteria cr=s.createCriteria(User.class);
		cr.add(Restrictions.and(Restrictions.eq("username", uname),Restrictions.eq("password", pass)));
		List<User> list=cr.list();
		if(list!=null) {
			view.addObject("msg2","LogIn Successfully");
		}
		else {
			view.addObject("msg2","Failed to Login");
		}
		
		s.close();
		view.setViewName("home");	
		return view;
	}
	
	@RequestMapping("/register")
	public ModelAndView insertData(User u) {
		ModelAndView view=new ModelAndView();
		String name=u.getName();
		String uname=u.getUsername();
		String pass=u.getPassword();
		
		Session s=sf.openSession();
		Transaction tra=s.beginTransaction();
		Serializable nn=s.save(u);
		if(nn!=null) {
			view.addObject("msg","Account Created successfully");
		}
		else {
			view.addObject("msg","Failed to insert Data");
		}
		tra.commit();
		s.close();
		view.setViewName("home");	
		return view;
	}

	@RequestMapping("/homepage")
	public ModelAndView chechLogin() {
		ModelAndView view=new ModelAndView();
		view.setViewName("home");
		return view;
	}
	
	@RequestMapping("/gotologin")
	public ModelAndView gotoLogin() {
		ModelAndView view=new ModelAndView();
		view.setViewName("login");
		return view;
	}
	
	@RequestMapping("/gotohome")
	public ModelAndView gotoHome() {
		ModelAndView view=new ModelAndView();
		view.setViewName("home");
		return view;
	}
	
	@RequestMapping("/gotoregister")
	public ModelAndView gotoRegister() {
		ModelAndView view=new ModelAndView();
		view.setViewName("register");
		return view;
	}
	
//	@RequestMapping("/gotoshowdata")
//	public ModelAndView gotoShow() {
//		ModelAndView view=new ModelAndView();
//		view.setViewName("show");
//		return view;
//	}
}
